MISBHA Android Project
1. Open this project in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated APK on an Android phone.
This project wraps the MISBHA HTML app in an Android WebView.
